const textArea = document.getElementById('textArea');
const charCount = document.getElementById('charCount');
const wordCount = document.getElementById('wordCount');
const remaining = document.getElementById('remaining');
const progress = document.getElementById('progress');

textArea.addEventListener('input', updateCounts);

function updateCounts() {
  const text = textArea.value;
  const chars = text.length;
  const words = text.trim() === '' ? 0 : text.trim().split(/\s+/).length;
  const remain = 500 - chars;
  
  charCount.textContent = chars;
  wordCount.textContent = words;
  remaining.textContent = remain;
  
  const percentage = (chars / 500) * 100;
  progress.style.width = percentage + '%';
  
  if (remain < 50) {
    remaining.style.color = '#f44336';
  } else {
    remaining.style.color = '#667eea';
  }
}