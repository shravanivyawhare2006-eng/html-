let count = 0;
const display = document.getElementById('display');
const increaseBtn = document.getElementById('increaseBtn');
const decreaseBtn = document.getElementById('decreaseBtn');
const resetBtn = document.getElementById('resetBtn');

// Load saved count from localStorage
count = parseInt(localStorage.getItem('count')) || 0;
updateDisplay();

increaseBtn.addEventListener('click', () => {
  count++;
  updateDisplay();
  saveCount();
});

decreaseBtn.addEventListener('click', () => {
  count--;
  updateDisplay();
  saveCount();
});

resetBtn.addEventListener('click', () => {
  count = 0;
  updateDisplay();
  saveCount();
});

function updateDisplay() {
  display.textContent = count;
  display.style.color = count > 0 ? '#4CAF50' : count < 0 ? '#f44336' : 'white';
}

function saveCount() {
  localStorage.setItem('count', count);
}