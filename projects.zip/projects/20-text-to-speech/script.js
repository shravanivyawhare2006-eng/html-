const textInput = document.getElementById('textInput');
const voiceSelect = document.getElementById('voiceSelect');
const rateSlider = document.getElementById('rateSlider');
const speakBtn = document.getElementById('speakBtn');
const pauseBtn = document.getElementById('pauseBtn');
const resumeBtn = document.getElementById('resumeBtn');
const stopBtn = document.getElementById('stopBtn');

const synth = window.speechSynthesis;
let voices = [];

// Get available voices
function populateVoiceList() {
  voices = synth.getVoices();
  voiceSelect.innerHTML = '';
  voices.forEach((voice, index) => {
    const option = new Option(voice.name, index);
    voiceSelect.add(option);
  });
}

if (synth.onvoiceschanged !== undefined) {
  synth.onvoiceschanged = populateVoiceList;
}
populateVoiceList();

speakBtn.addEventListener('click', () => {
  synth.cancel();
  const utterance = new SpeechSynthesisUtterance(textInput.value);
  utterance.voice = voices[voiceSelect.selectedIndex];
  utterance.rate = parseFloat(rateSlider.value);
  synth.speak(utterance);
});

pauseBtn.addEventListener('click', () => {
  synth.pause();
});

resumeBtn.addEventListener('click', () => {
  synth.resume();
});

stopBtn.addEventListener('click', () => {
  synth.cancel();
});