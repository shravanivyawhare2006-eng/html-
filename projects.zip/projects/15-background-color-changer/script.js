const randomBtn = document.getElementById('randomBtn');
const copyBtn = document.getElementById('copyBtn');
const colorPicker = document.getElementById('colorPicker');
const colorDisplay = document.getElementById('colorDisplay');
const body = document.body;

const savedColor = localStorage.getItem('bgColor') || '#ffffff';
setBackgroundColor(savedColor);
colorPicker.value = savedColor;

randomBtn.addEventListener('click', () => {
  const randomColor = '#' + Math.floor(Math.random()*16777215).toString(16).toUpperCase().padStart(6, '0');
  setBackgroundColor(randomColor);
});

copyBtn.addEventListener('click', () => {
  const color = colorDisplay.textContent;
  navigator.clipboard.writeText(color).then(() => {
    alert(`Copied: ${color}`);
  });
});

colorPicker.addEventListener('change', (e) => {
  const color = e.target.value.toUpperCase();
  setBackgroundColor(color);
});

function setBackgroundColor(color) {
  body.style.background = color;
  colorDisplay.textContent = color;
  colorPicker.value = color;
  localStorage.setItem('bgColor', color);
}