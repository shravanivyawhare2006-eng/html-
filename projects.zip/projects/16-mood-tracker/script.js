let selectedMood = null;
const moodBtns = document.querySelectorAll('.mood-btn');
const notesArea = document.getElementById('notes');
const saveBtn = document.getElementById('saveBtn');
const historyDiv = document.getElementById('history');

moodBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    moodBtns.forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    selectedMood = {
      emoji: btn.dataset.mood,
      label: btn.dataset.label
    };
  });
});

saveBtn.addEventListener('click', () => {
  if (!selectedMood) {
    alert('Please select a mood!');
    return;
  }
  
  const entry = {
    date: new Date().toLocaleString(),
    mood: selectedMood,
    notes: notesArea.value
  };
  
  let history = JSON.parse(localStorage.getItem('moodHistory')) || [];
  history.unshift(entry);
  localStorage.setItem('moodHistory', JSON.stringify(history));
  
  notesArea.value = '';
  moodBtns.forEach(b => b.classList.remove('selected'));
  selectedMood = null;
  
  displayHistory();
});

function displayHistory() {
  const history = JSON.parse(localStorage.getItem('moodHistory')) || [];
  historyDiv.innerHTML = '<h3>History</h3>';
  
  if (history.length === 0) {
    historyDiv.innerHTML += '<p>No moods recorded yet.</p>';
    return;
  }
  
  history.slice(0, 5).forEach(entry => {
    historyDiv.innerHTML += `
      <div class="mood-entry">
        <div>${entry.mood.emoji} ${entry.mood.label}</div>
        <div class="entry-date">${entry.date}</div>
        ${entry.notes ? `<p>${entry.notes}</p>` : ''}
      </div>
    `;
  });
}

displayHistory();