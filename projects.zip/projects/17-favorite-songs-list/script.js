const songInput = document.getElementById('songInput');
const artistInput = document.getElementById('artistInput');
const addBtn = document.getElementById('addBtn');
const songsList = document.getElementById('songsList');

let songs = JSON.parse(localStorage.getItem('songs')) || [];

addBtn.addEventListener('click', addSong);
songInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') addSong();
});

function addSong() {
  const song = songInput.value.trim();
  const artist = artistInput.value.trim();
  
  if (!song || !artist) {
    alert('Please fill in both fields!');
    return;
  }
  
  songs.push({ id: Date.now(), song, artist });
  localStorage.setItem('songs', JSON.stringify(songs));
  
  songInput.value = '';
  artistInput.value = '';
  displaySongs();
}

function displaySongs() {
  songsList.innerHTML = '';
  songs.forEach(({ id, song, artist }) => {
    const li = document.createElement('li');
    li.className = 'song-item';
    li.innerHTML = `
      <div class="song-info">
        <h3>${song}</h3>
        <p>${artist}</p>
      </div>
      <button class="delete-btn" onclick="deleteSong(${id})">Delete</button>
    `;
    songsList.appendChild(li);
  });
}

function deleteSong(id) {
  songs = songs.filter(s => s.id !== id);
  localStorage.setItem('songs', JSON.stringify(songs));
  displaySongs();
}

displaySongs();