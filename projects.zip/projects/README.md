# 🌐 Full Stack Fundamentals

> A curated collection of **10 beginner-to-intermediate frontend projects** demonstrating core HTML, CSS, and JavaScript concepts. Perfect for learning, portfolio building, and interview prep. **Zero dependencies — just HTML, CSS, and Vanilla JavaScript.**

## 🎯 Quick Start

1. **Clone the repository**
   ```bash
   git clone https://github.com/YOUR_USERNAME/fullstack-fundamentals.git
   cd fullstack-fundamentals
   ```

2. **Open any project** — Just double-click `index.html` in any folder, or open it in your browser:
   ```bash
   # On macOS
   open 01-digital-clock/index.html
   
   # On Windows (PowerShell)
   start 01-digital-clock/index.html
   
   # On Linux
   xdg-open 01-digital-clock/index.html
   ```

3. **Or visit the interactive dashboard** — Open `index.html` in the root folder to see all projects with descriptions.

---

## 📁 Project Overview

| # | Project | Key Concepts | Difficulty |
|---|---------|-------------|-----------|
| 01 | [Digital Clock](./01-digital-clock/) | DOM manipulation, `setInterval`, Date API, CSS animations | ⭐ Easy |
| 02 | [To-Do List](./02-todo-list/) | CRUD operations, `localStorage`, event handling | ⭐⭐ Medium |
| 03 | [Calculator](./03-calculator/) | Functions, conditionals, keyboard events, state management | ⭐⭐ Medium |
| 04 | [Quiz App](./04-quiz-app/) | Arrays of objects, dynamic rendering, score tracking | ⭐⭐ Medium |
| 05 | [Weather Card](./05-weather-card/) | Fetch API, `async/await`, REST APIs, error handling | ⭐⭐ Medium |
| 06 | [Color Palette Generator](./06-color-palette-generator/) | HSL color math, Clipboard API, CSS Grid | ⭐⭐⭐ Hard |
| 07 | [Form Validator](./07-form-validator/) | Regex, real-time validation, password strength | ⭐⭐⭐ Hard |
| 08 | [Image Gallery](./08-image-gallery/) | CSS Masonry, Lightbox functionality, filtering | ⭐⭐⭐ Hard |
| 09 | [Expense Tracker](./09-expense-tracker/) | Data aggregation, CSS charts, categories | ⭐⭐⭐ Hard |
| 10 | [Notes App](./10-notes-app/) | Two-panel layout, auto-save, search/filter, CRUD | ⭐⭐⭐⭐ Advanced |

---

## 🧠 Learning Concepts

### HTML Fundamentals
- ✅ Semantic markup (`<header>`, `<main>`, `<section>`, `<article>`)
- ✅ Form elements and validation
- ✅ Accessibility best practices & ARIA roles
- ✅ Data attributes for JavaScript integration

### CSS Mastery
- ✅ Flexbox & CSS Grid layouts
- ✅ CSS Variables (custom properties)
- ✅ Animations & transitions
- ✅ Responsive design & media queries
- ✅ Pseudo-classes & pseudo-elements
- ✅ CSS filters, transforms, and effects

### JavaScript (ES6+)
- ✅ DOM selection & manipulation
- ✅ Event listeners & event delegation
- ✅ Async/await & Promises
- ✅ `localStorage` for data persistence
- ✅ Array methods: `map`, `filter`, `reduce`, `find`, `sort`
- ✅ Destructuring, spread operator, template literals
- ✅ Regular expressions (regex) for validation
- ✅ Date, Math, and other built-in APIs

### APIs & External Data
- ✅ Fetch API for HTTP requests
- ✅ Working with REST APIs
- ✅ Error handling & try-catch
- ✅ JSON data handling

---

## 🎓 Project Descriptions

### 01 · Digital Clock ⏰
A real-time clock displaying hours, minutes, and seconds with a blinking colon. Shows the current date and auto-detects your timezone.
- **Skills**: DOM manipulation, setInterval, Date object, CSS animations
- **API**: None

### 02 · To-Do List ✓
Full-featured task manager with CRUD operations, filter by status (All/Active/Done), and persistent storage using localStorage.
- **Skills**: Array methods, event handling, localStorage, DOM rendering
- **API**: None

### 03 · Calculator 🧮
iOS-style calculator supporting basic operations, keyboard input, decimal numbers, and operator chaining.
- **Skills**: Functions, conditionals, keyboard events, state management
- **API**: None

### 04 · Quiz App 📝
8-question web development quiz with animated progress bar, instant feedback, and final score display.
- **Skills**: Arrays of objects, dynamic rendering, score calculation, CSS transitions
- **API**: None

### 05 · Weather Card 🌤️
Displays current weather conditions (temperature, humidity, wind speed) using the free Open-Meteo API — **no API key required**.
- **Skills**: Fetch API, async/await, error handling, JSON parsing
- **API**: [Open-Meteo](https://open-meteo.com/) (Free, no auth)

### 06 · Color Palette Generator 🎨
Generates beautiful, harmonious color palettes with different schemes (analogous, triadic, pastel). Copy colors to clipboard with one click.
- **Skills**: HSL color math, Clipboard API, CSS Grid, localStorage
- **API**: None

### 07 · Form Validator ✅
Registration form with real-time inline validation, password strength meter, and regex-based field checks.
- **Skills**: Regex patterns, event listeners, form validation, UX feedback
- **API**: None

### 08 · Image Gallery 📸
Masonry-style photo grid with category filtering, hover effects, and a full-screen lightbox with keyboard navigation.
- **Skills**: CSS Masonry, lightbox logic, filtering, keyboard events
- **API**: [Lorem Picsum](https://picsum.photos/) (Free placeholder images)

### 09 · Expense Tracker 💰
Track income and expenses with category breakdown, visual bar charts (pure CSS), and local persistence.
- **Skills**: Data aggregation, CSV/JSON handling, localStorage, CSS charts
- **API**: None

### 10 · Notes App 📓
Two-panel notes application with auto-save, full-text search, note duplication, and dark theme. Full CRUD with localStorage.
- **Skills**: Two-way data binding, auto-save, search algorithm, localStorage CRUD
- **API**: None

---

## 🛠 Technology Stack

| Technology | Purpose |
|-----------|---------|
| **HTML5** | Semantic structure and accessibility |
| **CSS3** | Styling, layout (Flexbox/Grid), animations |
| **Vanilla JavaScript (ES6+)** | All logic and interactivity — no frameworks |
| **localStorage API** | Client-side data persistence |
| **Fetch API** | HTTP requests to external APIs |
| **Open-Meteo API** | Free weather data (no authentication needed) |
| **Lorem Picsum** | Free placeholder images |

---

## 💡 Key Features

- ✨ **Zero Dependencies** — No npm packages, build tools, or frameworks
- 🚀 **Learn by Doing** — Hands-on projects with real-world functionality
- 📱 **Responsive Design** — Works perfectly on desktop, tablet, and mobile
- 🎯 **Progressive Difficulty** — Start easy, progress to advanced concepts
- 📝 **Well-Commented Code** — Easy to understand and learn from
- 🔍 **Portfolio-Ready** — Impressive projects to showcase to employers
- 🎓 **Interview Prep** — Common questions and patterns covered

---

## 📚 How to Use This Repository

### For Learning
1. Start with **01-Digital-Clock** (easiest)
2. Work through projects in order
3. Read the code comments and experiment
4. Try modifying features or adding new ones

### For Interview Prep
- Study the **key concepts** for each project
- Practice explaining the code out loud
- Try to build similar projects from scratch
- Focus on projects 07-10 for advanced interviews

### For Portfolio Building
- Deploy projects to GitHub Pages (see below)
- Create a personal website linking to them
- Customize projects with your own features
- Add project descriptions to your resume

---

## 🚀 Deployment (GitHub Pages)

To publish your projects to the web:

1. **Push to GitHub**
   ```bash
   git add .
   git commit -m "Add Full Stack Fundamentals projects"
   git push origin main
   ```

2. **Enable GitHub Pages**
   - Go to your repo **Settings** → **Pages**
   - Select **Main** branch as source
   - Your projects will be live at `https://YOUR_USERNAME.github.io/fullstack-fundamentals/`

3. **View Your Portfolio**
   - Dashboard: `https://YOUR_USERNAME.github.io/fullstack-fundamentals/`
   - Individual projects: `https://YOUR_USERNAME.github.io/fullstack-fundamentals/01-digital-clock/`

---

## 📋 File Structure

```
fullstack-fundamentals/
├── index.html                          # Main dashboard
├── README.md                           # This file
├── LICENSE                             # MIT License
├── .gitignore                          # Git ignore file
│
├── 01-digital-clock/
│   └── index.html                      # Single-file project
├── 02-todo-list/
│   └── index.html
├── 03-calculator/
│   └── index.html
│
... (and 7 more projects)
│
└── 10-notes-app/
    └── index.html
```

Each project is a **single HTML file** with embedded CSS and JavaScript — simple and self-contained.

---

## 🎓 Who Should Use This?

- 📚 **Beginners** learning HTML, CSS, and JavaScript
- 👨‍💻 **Self-taught developers** building a portfolio
- 🔍 **Job seekers** preparing for coding interviews
- 👨‍🏫 **Educators** looking for project-based learning materials
- 🧪 **Anyone** wanting to master vanilla JavaScript without frameworks

---

## ✨ What's NOT Here

- ❌ React, Vue, Angular, or any frameworks
- ❌ Build tools (Webpack, Vite, etc.)
- ❌ Package managers (npm dependencies)
- ❌ Backend code or databases
- ❌ Complex architectural patterns

This is **vanilla JavaScript at its best** — fast, lightweight, and educational.

---

## 📝 License

**MIT License** — You're free to use, modify, and distribute these projects. See [LICENSE](./LICENSE) for details.

---

## 🤝 Contributing

Found a bug or want to suggest improvements? Feel free to:
1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## 🙋 Support & Questions

- 📖 Read the code comments in each project
- 🔗 Check the concepts covered in each project description
- 💬 Open an issue for bugs or questions
- 🌟 Star this repo if it helped you learn!

---

## 🎉 Highlights

> **"These projects helped me understand vanilla JavaScript fundamentals before moving to React."** — Happy Learner

> **"Perfect for practicing for my web dev interviews!"** — Job Seeker

> **"Great collection for teaching students real-world patterns."** — Educator

---

<div align="center">

### Made with ❤️ using only HTML, CSS, and Vanilla JavaScript

**No frameworks. No dependencies. Just pure web development fundamentals.**

[⭐ Star on GitHub](https://github.com/YOUR_USERNAME/fullstack-fundamentals) • [🎯 Open Dashboard](./index.html)

</div>
